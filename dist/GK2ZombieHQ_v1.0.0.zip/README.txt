GK2 Zombie HQ
=============
Count and manage your zombie workers in Graveyard Keeper 2.

WHAT IT DOES
- Count HUD (bottom-left by default): zombie icon + number of zombies. Optional
  "current / allowed" (set the value in settings; turns red when above).
- Manager panel (default hotkey F8): every zombie with name, type, skulls, collar, status.
- "Open" - the game's own zombie window (organs, talents, equipment).
- "Recall" - safely detach a zombie from its station, then move it to your store.

CONTROLS
- Z  : show/hide the HUD (configurable).
- F8 : open the manager panel (configurable).
- Click the HUD to open the panel; drag it to move.

SETTINGS: in-game "Mods" menu (language, HUD on/off, font size, offsets, allowed zombies, keys).

REQUIRES: BepInEx 5.4.23.5 x64 + GK2 Mod Framework (installed by "GK2 Mod Installer").

INSTALL: copy the BepInEx folder into the game folder (merge), or install this item via the
GK2 Workshop Auto-Loader / GK2 Mod Installer.

Not affiliated with the developers or publishers of Graveyard Keeper 2.
